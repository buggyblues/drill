# Drill 项目 AI 分析与功能扩展包

生成日期：2026-10-14
用途：供 AI 阅读现有产品、架构与源码，并在此基础上分析或实现新功能。

## 建议阅读顺序

1. `README.md`：项目状态、启动方式和目录说明。
2. `docs/产品文档.md`、`docs/技术架构.md`：产品模型和技术契约。
3. `docs/DECISIONS.md`、`docs/IMPLEMENTATION.md`：已采用决策、暂定值、实现边界和未完成项。
4. `docs/TEST_REPORT.md`、`docs/ACCEPTANCE.md` 及两份根目录核查报告：已有验证证据和后续验收项。
5. `docs/UIUX设计.md`、`docs/界面改造理念.md`：交互与视觉约束；参考截图位于 `docs/design-refs/`、`docs/recap-ui-validation/` 和 `validation/ui-refresh/`。
6. 按功能阅读 `packages/`、`apps/`、`infra/`、`tests/`。

`docs/产品文档.md` 和设计文档表达目标与约束；它们本身不能证明功能已实现。实现状态以源码为准，验证状态以报告和对应结果文件为准。`.brainstorm/research/` 是背景研究资料，不等同于已确认的产品决策。

## 开发环境

- Node.js：`package.json` 要求 `>=22.16.0`。
- 压缩包不含依赖安装目录；根目录及 workspace 的 `package.json` 和 `package-lock.json` 已保留。需要时在解压目录运行 `npm install`。
- 常用检查命令：`npm test`、`npm run check`、`npm run build`。
- 若要运行本机示例：先运行 `npm install`，再运行 `npm run build:preview` 生成省略的 `preview/`，最后运行 `npm run demo`。示例会在本机 `.data/demo/` 写入虚构数据。
- `.env.example` 仅为配置模板；真实 `.env` 和本地数据不在包中。

## 目录重点

- `packages/core`：共享数据类型与同步协议。
- `packages/server`：HTTP、认证、存储、合并与 AI 逻辑。
- `packages/ui`、`packages/recap-ui`：共享界面和组件库源码。
- `apps/desktop`、`apps/web`、`apps/ios`：桌面、Web、iOS 客户端。
- `infra/`：数据库迁移、容器和向量服务。
- `tests/`：自动化测试源码。

## 本包刻意省略

- `node_modules/`：已安装的第三方依赖；可通过 npm 和锁文件恢复。
- `apps/**/dist/`、`preview/`：编译/预生成产物，可由源码重建。
- `.data/`：本机运行数据。
- `.DS_Store` 和原 `MANIFEST.sha256`：系统杂项；原清单对应完整工作目录，不能用于这个筛选后的包。
- Git 元数据：当前工作目录没有 `.git`，因此包内不含版本历史。
